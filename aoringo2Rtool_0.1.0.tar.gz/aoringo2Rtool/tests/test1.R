library(aoringo2Rtool)


df <- data.frame(x = 1:10, y = rnorm(10))
hello_plot(df)
